//  Matthew | 26 feb 2026 | Timeline
void setup() {
  size(950,400);
}
void draw() {
background(2889);
drawRef();
histEvent(200,200,"2003",true, "Graduated high school in 2003");
histEvent(265,300,"2010",false, "Played in the NBA for the mami heat");
histEvent(115,300,"1984",false, "Born in 1984 in ohio");
histEvent(405,200,"2016",true, "Won a championship with the Cleveland Cavaliers");
histEvent(600,200,"2020",true, "Won a championship with the LA lakers");
histEvent(515,300,"2018",false, "Lebron james got injured with an left grion injury in the 2018 NBA season on christmas day ");
histEvent(715,300,"2023",false, "Lebron james son had a cardiac arrest during a wokout in 2023 ");
histEvent(850,200,"2025",true, "Won a championship with the LA lakers his most recent");
}
void drawRef() {
  textAlign(CENTER);
  textSize(24);
  fill(255);
text("LeBron James: Timeline",width/2,80);
text("By Matthew payne",width/2,110);
strokeWeight(2);
line(50,250,900,250); //timeline
line(50,245,50,255); // left tic
line(250,245,250,255);// right tic
line(700,245,700,255);
line(900,245,900,255);
line(450,245,450,255);
strokeWeight(3);
text("2026",900,270);
text("1980",50,270);
}
void histEvent(int x, int y, String title, boolean top, String detail) {
  if(top == true) {
  line(x,y,x-15,y+50);
  } else {
    line(x,y,x-15,y-50);
  }
  rectMode(CENTER);
  fill(60);
  rect(x,y,100,30,10);
  fill(255);
  text(title,x,y+5);
  if(mouseX > x-50 && mouseX <x+50 && mouseY > y-15 && mouseY < y+15) {
    text(detail,width/2,350);
  }
}
