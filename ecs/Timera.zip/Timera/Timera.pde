// Matthew Payne | 3/26/26 | Timer
Button btnStart, btnStop, btnReset;
int totalTime = 10;
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  //alarm = new SoundFile (this, alarm.mp3);
  btnStart = new Button(400, 100, 100, 30, "Start", color(200), color(10));
  btnStop = new Button(100, 100, 100, 30, "Stop", color(200), color(10));
  btnReset = new Button(250, 150, 100, 30, "Reset", color(200), color(10));
  timeLeft = totalTime;
}

void draw() {
  background(180, 50, 185);

  if (running == true) {
    int elapsed = (millis() - startTime)/1000;
    timeLeft = totalTime - elapsed;

    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
    }
  }

  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  fill(100);
  rect(width/2, height/2, 100, 100);
  fill(255, 0, 0);
  textSize(100);
  text(timeLeft, width/2, height/2-15);
  btnReset.display();
  btnReset.hover();
 
}

void mousePressed() {
  if (btnStart.over == true) {
    running = true;
    startTime = millis();
 
  }
}

class Button {
  //Member varibales
  int x, y, w, h;
  String label;
  color c1, c2;
boolean over;
  // Constuctor
  Button(int x, int y, int w, int h, String label, color c1, color c2) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
    this.c1 = c1;
    this.c2 =c2;
    over = false;
  }

  //Member Methods
  void display() {
    if(over == true) {
      fill(c1);
    }    else{
      fill(c2);
    }
    rectMode(CENTER);
    rect(x, y, w, h, 50);
    fill(255, 255, 255);
    textAlign(CENTER, CENTER);
    textSize(25);
    text(label, x, y-5);
  }
  boolean hover() {
    if(mouseX > x-w/2 && mouseX < x+w/2 && mouseY > y-h/2 && mouseY < y+h/2) {
       over = true;
    }else {
      over = false;
    }
    return over;
  }
  
}
